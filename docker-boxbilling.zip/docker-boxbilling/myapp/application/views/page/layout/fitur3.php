  <!-- Fitur 3-->
  <section>
      <div class="container">
          <div class="line">
          </div>
          <p class="text-center primarytext h2 mt-2 mb-5">Semua Paket Hosting Sudah Termasuk</p>
          <div class="row p-5">
              <div class="col-lg-4 col-md-6 text-center mb-5">
                  <img src="<?= base_url() ?>Assets/svg/icon PHP Hosting_PHP Semua Versi.svg" alt="" srcset="" style="width: 20%;" class="mb-1">
                  <p class="primarytext h5 font-weight-bold">PHP Semua Versi</p>
                  <p class="primarytext">Pilih Mulai dari Versi
                      PHP 5.3 s/d PHP 7.<br>Ubah sesuka anda.</p>
              </div>
              <div class="col-lg-4 col-md-6 text-center mb-5">
                  <img src="<?= base_url() ?>Assets/svg/icon PHP Hosting_My SQL.svg" alt="" srcset="" style="width: 20%;" class="mb-1">
                  <p class="primarytext h5 font-weight-bold">MySQL Versi 5.6</p>
                  <p class="primarytext"> Nikmati MySQL versi terbaru,tercepat dan <br> kaya akan fitur.</p>
              </div>
              <div class="col-lg-4 col-md-6 text-center mb-5">
                  <img src="<?= base_url() ?>Assets/svg/icon PHP Hosting_CPanel.svg" alt="" srcset="" style="width: 20%;" class="mb-1">
                  <p class="primarytext h5 font-weight-bold">Panel Hosting cPaneli</p>
                  <p class="primarytext">Kelola website dangan panel canggih yang <br> familiar di hati anda.</p>
              </div>
              <div class="col-lg-4 col-md-6 text-center mb-5">
                  <img src="<?= base_url() ?>Assets/svg/icon PHP Hosting_garansi uptime.svg" alt="" srcset="" style="width: 20%;" class="mb-1">
                  <p class="primarytext h5 font-weight-bold">Garansi Uptime 99.9%</p>
                  <p class="primarytext"> Data center yang mendukung kelangsungan<br> website anda 24/7.</p>
              </div>
              <div class="col-lg-4 col-md-6 text-center mb-5">
                  <img src="<?= base_url() ?>Assets/svg/icon PHP Hosting_InnoDB.svg" alt="" srcset="" style="width: 20%;" class="mb-1">
                  <p class="primarytext h5 font-weight-bold">Database InnoDB Unlimited</p>
                  <p class="primarytext"> Jumlah dan ukuran database yang tumbuh<br> sesuai kebutuhan anda.</p>
              </div>
              <div class="col-lg-4 col-md-6 text-center mb-5">
                  <img src="<?= base_url() ?>Assets/svg/icon PHP Hosting_My SQL remote.svg" alt="" srcset="" style="width: 20%;" class="mb-1">
                  <p class="primarytext h5 font-weight-bold">Wildcard Remote MySQL</p>
                  <p class="primarytext">JMendukung s/d 25 Max_user_connections<br> dan 100 Max_user_connections.</p>
              </div>
          </div>
          <div class="line">
          </div>
      </div>
  </section>
  <!-- Akhir Fitur -->