<!-- Fitur -->
<section class="p-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 text-center">
                <img src="<?= base_url() ?>Assets/svg/zenguard1.svg" alt="" srcset="" class="mt-5 mb-5"><br>
                <p class="text-center nav-text mt-5">PHP Zend Guard Loader</p>
            </div>
            <div class="col-md-4 text-center">
                <img src="<?= base_url() ?>Assets/svg/composer.svg" alt="" srcset="" class="mb-3">
                <p class="text-center nav-text mt-3">PHP Composer</p>
            </div>
            <div class="col-md-4 text-center">
                <img src="<?= base_url() ?>Assets/svg/ioncube.svg" alt="" srcset="" class="mt-5 mb-5"><br>
                <p class="text-center nav-text mt-5">PHP IonCube Loader</p>
            </div>
        </div>
    </div>
</section>
<!-- Akhir Fitur -->