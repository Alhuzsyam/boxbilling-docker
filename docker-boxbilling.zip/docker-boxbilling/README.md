# Docker Boxbilling

NIAGAHOSTER TASK 2 BOXBILLING & LANDINGPAGE ON DOCKER

## Installation Step

1. Clone this repository
2. `cd` to docker-boxbilling directory
3. Run `docker-compose build`
4. Run `docker-compose up -d`
5. You can Also Run both whith this command `docker-compose up --build -d`
6. This file contain are boxbilling, landingpage with code igniter framework and mysql databse
   - Boxbilling Run on Port 8040
   - Mysql Run on Port 3306
   - Landingpage Run on Port 8000

## Screenshot
